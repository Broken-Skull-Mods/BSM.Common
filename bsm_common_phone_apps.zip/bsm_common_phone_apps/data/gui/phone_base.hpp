
class BSM_DT_Tablet_BASE {
    class controls {
		class Frame_Base;
		class Frame_Base_Picture;
		class Button_Home_Base;
		class Button_Up_Base;
		class Button_Down_Base;
		class Button_Exit_Base;
    };
};
